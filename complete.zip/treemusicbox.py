from bottle import route, run, template
import RPi.GPIO as GPIO
import time
import threading
import os


GPIO.setmode(GPIO.BCM)
leds = [18, 23, 25]
ledStates = [0, 0, 0]
button = 24
GPIO.setup(leds[0], GPIO.OUT)
GPIO.setup(leds[1], GPIO.OUT)
GPIO.setup(leds[2], GPIO.OUT)
GPIO.setup(button, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

def update_leds():
    while True:
        for i, value in enumerate(ledStates):       
            GPIO.output(leds[i], True)
            time.sleep(1)
            GPIO.output(leds[i], False)
            time.sleep(1)
                
def music():
    os.system("vlc b.mp3")
           
def moter():
    os.system("python moter.py")
    
control_page = """

<script>
function changed(id)
{
window.location.href='/' + id
}
</script>
<style>
body {
    background-color : #F6CECE
    }
</style>
<h1>Tree Music Box</h1>
<h2>Click the command button(Music, Turn, LED)</h2>
<h2>LED</h2>
<input type='button' onClick='changed({{led0}})' value='Music'/>
<input type='button' onClick='changed({{led1}})' value='Turn'/>
<input type='button' onClick='changed({{led2}})' value='LED'/>
"""


@route('/')
@route('/<led>')
def index(led="n"):
    if led == "0" and led != "favicon.ico":
        t = threading.Thread(target=music)
        t.start()
    
    elif led == "1" and led != "favicon.ico":
        t2 = threading.Thread(target=moter)
        t2.start()
        
    elif led == "2" and led != "favicon.ico":
        num = int(led)
        ledStates[num] = not ledStates[num]
        t3 = threading.Thread(target=update_leds)
        t3.start()
        
        
        
    state = GPIO.input(button)
    return template(control_page, btnState=state,
led0=0, led1=1, led2=2)


run(host='localhost', port=8080)